﻿New-Item -Path 'C:\temp' -ItemType Directory -Force | Out-Null

Start-Transcript `
-Path 'C:\temp\installation.log' `
-IncludeInvocationHeader 


#endregion

#region Begin Clean APPX Packages


If (Test-Path c:\temp\opt\2004\ConfigurationFiles\AppxPackages.json)
{
    $AppxPackage = Get-Content c:\temp\opt\2004\ConfigurationFiles\AppxPackages.json | ConvertFrom-Json 
    $AppxPackage = $AppxPackage | Where-Object { $_.VDIState -eq 'Disabled' }
}

If ($AppxPackage.Count -gt 0)
{
    Foreach ($Item in $AppxPackage)
    {
        $Package = "*$($Item.AppxPackage)*"
        Write-Verbose "Attempting to remove $($Item.AppxPackage) - $($Item.Description)"
        Get-AppxPackage -Name $Package | Remove-AppxPackage -ErrorAction SilentlyContinue  | Out-Null
        
        Write-Verbose "Attempting to remove [All Users] $($Item.AppxPackage) - $($Item.Description)"
        Get-AppxPackage -AllUsers -Name $Package | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue 
        
        Write-Verbose "Removing Provisioned Package $($item.AppxPackage)"
        Get-AppxProvisionedPackage -Online | Where-Object { $_.PackageName -like $Package } | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Out-Null
    }
}
#endregion

#region Disable Scheduled Tasks

# This section is for disabling scheduled tasks.  If you find a task that should not be disabled
# change its "VDIState" from Disabled to Enabled, or remove it from the json completely.
If (Test-Path c:\temp\opt\2004\ConfigurationFiles\ScheduledTasks.json)
{
    $SchTasksList = Get-Content c:\temp\opt\2004\ConfigurationFiles\ScheduledTasks.json | ConvertFrom-Json
    $SchTasksList = $SchTasksList | Where-Object { $_.VDIState -eq 'Disabled' }
}
If ($SchTasksList.count -gt 0)
{
    #$EnabledScheduledTasks = Get-ScheduledTask | Where-Object { $_.State -ne "Disabled" }
    Foreach ($Item in $SchTasksList)
    {
        #$Task = (($Item -split ":")[0]).Trim()
        Write-Verbose "Disabling Scheduled Task $($Item.ScheduledTask)"
        Disable-ScheduledTask -TaskName $Item.ScheduledTask -ErrorAction SilentlyContinue
        #$EnabledScheduledTasks | Where-Object { $_.TaskName -like "*$Task*" } #| Disable-ScheduledTask
    }
}
#endregion



#region Disable Services
If (Test-Path c:\temp\opt\2004\ConfigurationFiles\Services.json)
 
{
    $ServicesToDisable = Get-Content c:\temp\opt\2004\ConfigurationFiles\Services.json | ConvertFrom-Json
}

If ($ServicesToDisable.count -gt 0)
{
    $ServicesToDisable = $ServicesToDisable | Where-Object { $_.VDIState -eq 'Disabled' }
    Foreach ($Item in $ServicesToDisable)
    {
        Write-Verbose "Stopping $($Item.Name) - $($Item.Description)"
        Stop-Service $Item.Name -Force -ErrorAction SilentlyContinue
        Write-Verbose "`t`tDisabling $($Item.Name)"
        Set-Service $Item.Name -StartupType Disabled 
    }
}
#endregion

$EndTime = Get-Date
$ScriptRunTime = New-TimeSpan -Start $StartTime -End $EndTime
Write-Host "Total Run Time: $($ScriptRunTime.Hours) Hours $($ScriptRunTime.Minutes) Minutes $($ScriptRunTime.Seconds) Seconds" -ForegroundColor Cyan

Stop-Transcript